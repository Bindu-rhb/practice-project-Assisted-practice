package TESTNG;

public @interface test {

}
