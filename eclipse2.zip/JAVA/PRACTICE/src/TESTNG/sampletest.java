package TESTNG;

import org.testng.annotations.Test;

public class sampletest {
	 @Test

	 public void firsttestcase() {
       System.out.println("this is first");
	 }
	 @Test
	 
	 public void secondtestcase() {
		 System.out.println("this is second");
	 }
	 @Test
	 
	
	 public void thirdtestcase() {
		 System.out.println("this is third");
	 }
	 @Test
	 
	 
	 public void fourthtestcase() {
		 System.out.println("this is fourth");
	 }
}