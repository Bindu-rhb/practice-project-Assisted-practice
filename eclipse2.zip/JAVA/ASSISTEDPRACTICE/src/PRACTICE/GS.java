package PRACTICE;

public class GS {
	
	// Parmeterized methods: you pass the variable value to the method when the method is called
	// Step 1: Every method should declare parameters(variables)
	// steps 2: parameters are written with the method name inside the () brackets
	// when the method is called, it is expecting variables values
	
	public static void openbrowser(String browserName,String appURL)
	{
		System.out.println("Code to open the browser for testing in : " + browserName);
		System.out.println("Code to open the app on the browser for testing in : " + appURL);
		
	}
	
	public void login(String userName, String password)
	{
		System.out.println("Code for username "+ userName);
		System.out.println("code for password" + password);
		System.out.println("User logged successfully");
	}

	public static void main(String[] args) {
		
		GS obj  = new GS();
		
	// calling a method without an object--> as the method is marked as Static method
		
		openbrowser("Chrome","google.com");
		
// calling a method with an object --> as the method is not marked as static
		
		obj.login("sonal","sonal@13");
		
		openbrowser("Firefox","google.com");
		
				
		obj.login("admin","admin@13");
				
		openbrowser("Edge","gmail.com");
		
		
		obj.login("simplilearn","sl@13");
		
		

	}

}

