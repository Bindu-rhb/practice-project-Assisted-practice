package PRACTICE;

public class CalculateArea {
    public static void main(String[] args) {
        double length = 5.0;
        double width = 3.0;
        double radius = 4.0;
        double base = 6.0;
        double height = 8.0;

        double rectangleArea = length * width;
        double circleArea = Math.PI * radius * radius;
        double triangleArea = 0.5 * base * height;

        System.out.println("The area of the rectangle is " + rectangleArea);
        System.out.println("The area of the circle is " + circleArea);
        System.out.println("The area of the triangle is " + triangleArea);
    }
}
