package PRACTICE;

public class P6UserdefinedVoidMethod {
	
	// methods which will not return any value ==> void methods
	// methods have no return statement
	
	public void login()
	{
		System.out.println("Open Chrome broswer");
		System.out.println("Open URL on broswer");
		System.out.println("enter user credentials");
		System.out.println("Click on login button");
	}
	
	public void add ()
	{
		int a = 100; 
		int b = 200;
		int result = a + b;
		System.out.println("The sum of 2 numbers"  + result);
	}
	

	public static void main(String[] args) {
		
		P6UserdefinedVoidMethod obj1 = new P6UserdefinedVoidMethod();
		
		obj1.login();
		
		    obj1.add();
		
		

	}

}

