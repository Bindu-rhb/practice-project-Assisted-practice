package PRACTICE;

public class P8ParametrizationMethods {
	
	// Step 1:
	
	public static void openbrowser()
	{
		String browserName = "Chrome";
		String appURL = "Google.com";
		System.out.println("Code to open the browser for testing in : " + browserName);
		System.out.println("Code to open the app on the browser for testing in : " + appURL);
		
	}
	
	public void login()
	{
		String userName = "Sonal";
		String password = "pass@123";
		System.out.println("Code for username "+ userName);
		System.out.println("code for password" + password);
		System.out.println("User logged successfully");
	}

	public static void main(String[] args) {
		
		P8ParametrizationMethods obj  = new P8ParametrizationMethods();
		
	// calling a method without an object--> as the method is marked as Static method
		
		openbrowser();
		
// calling a method with an object --> as the method is not marked as static
		
		obj.login();
		
		

	}

}
