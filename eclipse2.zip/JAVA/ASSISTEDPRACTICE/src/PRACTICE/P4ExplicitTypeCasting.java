package PRACTICE;

public class P4ExplicitTypeCasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		double d1 = 23.756;
		
		int a = (int)d1;
		
		System.out.println("the value of d1 is not converted to integer " + a);
		
		// Convert an Integer to a String
		
		int phone = 987869807;
		
		String phonenumber = Integer.toString(phone);
		
		System.out.println(phonenumber);
		
		// Convert an Integer to a String
		
		
		String s2 = String.valueOf(phone);
		
		
		System.out.println(s2);
		
		// Convert String to an Integer
		
		
		
		String age = "89";
		
		int i = Integer.parseInt(age);
		
		System.out.println(i);	
		
	
	}
}
