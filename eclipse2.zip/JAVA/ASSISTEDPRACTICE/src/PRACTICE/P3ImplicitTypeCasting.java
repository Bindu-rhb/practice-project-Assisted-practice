package PRACTICE;

public class P3ImplicitTypeCasting {
	
	public static void main(String args[]) {
	
	// Type casting : convert data type of 1 variable to another datatype
	
	int a = 100;
	
	// using implicit type casting method in java
 //we can store smaller byte data type into a bigger data type
	
	double d1 = a;  // value of d1 will be a decimal value
	
	System.out.println("the value is " + d1);
	
}
}