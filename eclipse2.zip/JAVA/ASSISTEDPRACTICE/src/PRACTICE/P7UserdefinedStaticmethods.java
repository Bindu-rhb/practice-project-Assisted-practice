package PRACTICE;

import java.util.Scanner;

public class P7UserdefinedStaticmethods {
	
	public static void make_payment()
	{
		 Scanner   scan   =  new Scanner(System.in);
	     System.out.println("Enter your payment :");
	    int payment = scan.nextInt();
	    System.out.println("Enter your tax amount :");
	    int tax = scan.nextInt();
	    int finalpayment = payment + tax;
	    System.out.println("Payment entered by user is  " + finalpayment);	
		
	}
	
	public static int payment2()
	{
		 Scanner   scan   =  new Scanner(System.in);
	     System.out.println("Enter your payment for food :");
	    int payment = scan.nextInt();
	    System.out.println("Enter your tax amount :");
	    int tax = scan.nextInt();
	    int finalpayment = payment + tax;
	   
	    return finalpayment;
		
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
	/*	P7UserdefinedStaticmethods obj = new P7UserdefinedStaticmethods();
		
		obj.make_payment();  // void method , directly prints the output
		
		int userpayment = obj.payment2();  // this method returns  a int value
		
		System.out.println("the payment for food by user is : " + userpayment); */

		
		// these are static methods, so we dont need an object to call them. we can call them just by the mthoed name
		
		make_payment();
		
		int userpayment = payment2();
		
		System.out.println("the payment for food by user is : " + userpayment);
		

	}

}




