package PRACTICE;

import java.util.Scanner;

public class P2ScannerDemo {
	
	public static void main(String args[]) {
		
		// we need to take input form user==> use a java inbuilt class Scanner
		
	      // create object of scanner class and give a name to the object
		   
		     Scanner   scan   =  new Scanner(System.in);
		     
		     System.out.println("Enter your name :");
		    String name = scan.next();
		    // next is a method of scanner class which take input as String from user as runtim
		   
		    System.out.println("Enter your age :");
		    int age = scan.nextInt(); // method which take input as int from user 
		    
		    System.out.println("the user name is = " + name);
		    System.out.println("the user age is = " + age);
		
		
	}

}

