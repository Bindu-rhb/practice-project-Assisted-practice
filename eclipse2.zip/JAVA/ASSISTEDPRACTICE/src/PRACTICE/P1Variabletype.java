package PRACTICE;

public class P1Variabletype {

public static void main(String[] args) {
	
	// variables are temporary memory locations that stores some data
	
//Integer data type: int
	
	int a = 10;
	int  var1 = 100;
	
	// print the value of the variable
	
	System.out.println("the value of variable a = " + a );  // will print => the value of variable a = 10 

	System.out.println("the value of variable a = " + var1 );
	
//dclare a variable which will store decimal value
	
	double d1 = 2.3456;
	double d2 = 4.678;
	
	System.out.println("the value of variable d1 = " + d1 );   
	
	System.out.println("the value of variable d2 = " + d2 );
	
//declare a variable which store alphanumerical value
	
	String s1 = "Selenium" ; 
	String s2 = "Selenium@9Am" ;
	
System.out.println("the value of variable s1 = " + s1 );  // will print => the value of variable a = 10 
	
	System.out.println("the value of variable s2 = " + s2 );
	
	

}

}

