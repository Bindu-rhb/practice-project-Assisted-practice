package JAVAPROGRAMS;


	public class Shape {
		
		public void displayArea()
		{
			System.out.println("The shape is not having any area calculation method");
		}
	}


