package JAVAPROGRAMS;

public class forloop {
	public class ForLoop 
	{ 
	   public static void main(String args[]) 
	    { 
	      
	        for (int x = 2; x <= 4; x++) 
	            System.out.println("Value of x:" + x); 
	    } 
	} 


}
