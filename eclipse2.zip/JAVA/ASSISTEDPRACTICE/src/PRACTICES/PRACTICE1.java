package PRACTICES;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.ListIterator;

public class PRACTICE1 {

	public static void main(String[] args) {
		/*using string buffer
		 * String given ="name";
		StringBuffer buffer=new StringBuffer();
		buffer.append(given);
      System.out.println(buffer.reverse());
		// TODO Auto-generated method stub
*/
		/*using own logic
		 * String given="NAME";
		char[] characterArray=given.toCharArray();
	    String reversed="";
		for (int i=characterArray.length-1;i>=0;i--) {
			reversed=reversed+characterArray[i];	
		}
	System.out.println(reversed);*/
		//using collections
		String given="name";
		char[] array=given.toCharArray();
		List<Character> list=new ArrayList<Character>();		
		for (Character character : array) {
			list.add(character);
		}
		Collections.reverse(list);
		ListIterator iterator=list.listIterator();
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
			
		
		}
	}
}

