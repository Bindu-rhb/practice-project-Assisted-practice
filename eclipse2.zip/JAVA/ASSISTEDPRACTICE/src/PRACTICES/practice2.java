package PRACTICES;

public class practice2 {

	public static void main(String[] args) {
		int mysalary =20;
		int superiorsalary=2000;
		System.out.println("BEFORE SWAPPING"+ "MINE:"+mysalary+"superior:"+superiorsalary);
		int temp =mysalary;
		mysalary=superiorsalary;
		superiorsalary=temp;
		System.out.println("AFTER SWAPPING"+ "MINE:"+mysalary+"superior:"+superiorsalary);
		
		// TODO Auto-generated method stub

	}

}
