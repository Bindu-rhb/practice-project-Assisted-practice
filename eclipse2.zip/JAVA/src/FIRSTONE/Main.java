package FIRSTONE;

class Rectangle {
    void calculateArea(double length, double width) {
        double area = length * width;
        System.out.println("Area of the rectangle: " + area);
    }
}

class Circle {
    static final double PI = Math.PI;

    void calculateArea(double radius) {
        double area = PI * radius * radius;
        System.out.println("Area of the circle: " + area);
    }
}

class Triangle {
    void calculateArea(double base, double height) {
        double area = 0.5 * base * height;
        System.out.println("Area of the triangle: " + area);
    }
}

public class Main {
    public static void main(String[] args) {
        Rectangle rectangle = new Rectangle();
        rectangle.calculateArea(5, 8);

        Circle circle = new Circle();
        circle.calculateArea(3);

        Triangle triangle = new Triangle();
        triangle.calculateArea(6, 4);
    }
}


