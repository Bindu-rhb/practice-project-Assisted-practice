package setup;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import java.util.ArrayList;

public class XC {
    public static void main(String[] args) {
        // Set the path to the chromedriver executable
       // System.setProperty("webdriver.chrome.driver", "\"C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe\"");

        // Launch the Chrome browser
        WebDriver driver = new ChromeDriver();

        // Navigate to Google homepage
        driver.get("https://www.google.com");

        // Step 4.5.1: Edit box
        // Enter a value in the search box
        driver.findElement(By.name("q")).sendKeys("Hello World");

        // Clear the value
        driver.findElement(By.name("q")).clear();

        driver.findElement(By.name("q")).isEnabled();

        driver.findElements(By.name("q")).size();

        driver.findElement(By.name("q")).getAttribute("value");

        // Step 4.5.2: Link
        // Click the "Images" link
        driver.findElement(By.linkText("Images")).click();

        driver.findElements(By.linkText("Images")).size();

        driver.findElement(By.linkText("Images")).isEnabled();

        driver.findElement(By.linkText("Images")).getText();

        // Step 4.5.3: Button
        // Click the "Google Search" button
        driver.findElement(By.name("btnK")).click();

        driver.findElement(By.name("btnK")).isEnabled();

        driver.findElement(By.name("btnK")).isDisplayed();

        // Step 4.5.4: Image, image link, and image button
        // Operations on Image

        driver.findElement(By.tagName("textarea")).getAttribute("value");

        driver.findElement(By.name("btnI")).isDisplayed();

        driver.findElement(By.name("btnI")).isEnabled();

        driver.findElement(By.name("btnI")).isSelected();

        // Select the "I'm Feeling Lucky" checkbox
        driver.findElement(By.name("btnI")).click();

        // Unselect the "I'm Feeling Lucky" checkbox
        driver.findElement(By.name("btnI")).click();

        // Step 4.5.7: Radio button
        // Select the "Search" radio button
        driver.findElement(By.cssSelector("input[name='tbm'][value='s']")).click();

        driver.findElement(By.cssSelector("input[name='tbm'][value='s']")).isDisplayed();

        driver.findElement(By.cssSelector("input[name='tbm'][value='s']")).isEnabled();

        driver.findElement(By.cssSelector("input[name='tbm'][value='s']")).isSelected();

        driver.findElements(By.name("lang")).size();

        driver.findElement(By.name("lang")).isEnabled();

        // Select an item from the drop-down list
        Select dropdown = new Select(driver.findElement(By.name("lang")));
        dropdown.selectByVisibleText("English");
        dropdown.selectByValue("fr");

        dropdown.getOptions().size();
     driver.findElement(By.xpath("//table/tbody/tr[1]/td[1]")).getText();

        driver.findElements(By.xpath("//table/tbody/tr")).size();

        driver.findElements(By.xpath("//table/tbody/tr[1]/td")).size();

        // Step 4.5.10: Frame
        // Switch from the default content to a frame
        driver.switchTo().frame("frameName");

        // Switch back from a frame to the default content
        driver.switchTo().defaultContent();

        // Step 4.5.11: Switching between tabs in the same browser window
        // Open a new tab
        driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL + "t");

        // Switch to the newly opened tab
        ArrayList<String> tabs = new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));

        // Perform operations in the new tab

        // Switch back to the old tab
        driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL + "\t");
        driver.switchTo().defaultContent();

        // Perform operations in the old tab

        // Close the browser
        driver.quit();
    }
}



