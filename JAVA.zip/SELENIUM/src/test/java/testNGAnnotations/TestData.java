package testNGAnnotations;

import org.testng.annotations.DataProvider;

public class TestData {

    @DataProvider(name = "envData")
    public static Object[][] getEnvironmentData() {
        return new Object[][] {
                {"dev"},
                {"staging"},
                {"prod"}
        };
    }
}

