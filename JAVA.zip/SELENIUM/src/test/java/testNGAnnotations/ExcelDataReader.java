package testNGAnnotations;

import org.apache.poi.ss.usermodel.*;

import java.io.FileInputStream;
import java.io.IOException;

public class ExcelDataReader {

    public static Object[][] readExcel(String filePath, String sheetName) throws IOException {
        FileInputStream fileInputStream = new FileInputStream(filePath);
        Workbook workbook = WorkbookFactory.create(fileInputStream);
        Sheet sheet = workbook.getSheet(sheetName);

        int rowCount = sheet.getPhysicalNumberOfRows();
        int colCount = sheet.getRow(0).getPhysicalNumberOfCells();

        Object[][] data = new Object[rowCount - 1][colCount];

        for (int i = 1; i < rowCount; i++) {
            Row row = sheet.getRow(i);
            for (int j = 0; j < colCount; j++) {
                Cell cell = row.getCell(j);
                data[i - 1][j] = cell.toString();
            }
        }

        workbook.close();
        fileInputStream.close();

        return data;
    }

    public static void main(String[] args) throws IOException {
        String filePath = "\"C:\\ProgramData\\Microsoft\\Windows\\Start Menu\\Programs\\Microsoft Office\\Microsoft Excel 2010.lnk\"";
        String sheetName = "Sheet1";

        Object[][] testData = readExcel(filePath, sheetName);

        // Use testData as needed (e.g., print or use in Selenium tests)
        for (Object[] row : testData) {
            for (Object cellData : row) {
                System.out.print(cellData + "\t");
            }
            System.out.println();
        }
    }
}
