package testNGAnnotations;



import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class RedbusHomePageDemo {

    WebDriver driver;

    @BeforeClass
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "\"C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe\"");
        driver = new ChromeDriver();
        // Additional setup if needed
    }

    @Test
    public void bookBusTicket() {
        // Your test logic here
        // e.g., navigate to the bus ticket booking application, perform actions, and make assertions
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}

