package testNGAnnotations;

public class Baseclass {

}
