package testng;

public class testng1 {

}
